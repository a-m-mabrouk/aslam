type colorTypes =
  | "primary"
  | "primaryOutLine"
  | "primaryCancel"
  | "success"
  | "successOutLine"
  | "failure"
  | "failureOutLine"
  | "transparent"
  | "white";
