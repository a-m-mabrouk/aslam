import { createContext } from "react";

export const allCoursesContext = createContext<allCoursesContextType>(
  {} as allCoursesContextType,
);
